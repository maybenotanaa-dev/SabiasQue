#import "ViewController.h"
@interface ViewController ()
@property(nonatomic,strong) UISegmentedControl *categories;
@property(nonatomic,strong) UILabel *fact;
@property(nonatomic,assign) NSInteger index;
@property(nonatomic,strong) NSArray *facts;
@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.whiteColor;
    self.index = -1;
    self.facts = @[
      @[@"Un día en Venus es más largo que su año.",
        @"La luz del Sol tarda aproximadamente 8 minutos en llegar a la Tierra.",
        @"El ADN humano y el de los chimpancés es muy similar."],
      @[@"La primera página web fue creada en 1991.",
        @"Un byte está formado por 8 bits.",
        @"El código QR fue creado en Japón."],
      @[@"Los pulpos tienen tres corazones.",
        @"Los delfines pueden dormir con un hemisferio cerebral a la vez.",
        @"Las abejas pueden reconocer patrones y formas."]
    ];

    self.categories = [[UISegmentedControl alloc] initWithItems:@[@"Ciencia",@"Tecnología",@"Animales"]];
    self.categories.selectedSegmentIndex = 0;
    [self.categories addTarget:self action:@selector(categoryChanged:) forControlEvents:UIControlEventValueChanged];

    self.fact = [[UILabel alloc] init];
    self.fact.text = @"Pulsa el botón para descubrir un dato curioso.";
    self.fact.textAlignment = NSTextAlignmentCenter;
    self.fact.numberOfLines = 0;
    self.fact.font = [UIFont systemFontOfSize:18];

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"¿Sabías qué?" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    [button addTarget:self action:@selector(showFact:) forControlEvents:UIControlEventTouchUpInside];

    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[self.categories,self.fact,button]];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 30;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:stack];

    [NSLayoutConstraint activateConstraints:@[
      [stack.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:25],
      [stack.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-25],
      [stack.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor]
    ]];
}
- (void)categoryChanged:(UISegmentedControl *)sender {
    self.index = -1;
    self.fact.text = @"Pulsa el botón para descubrir un dato curioso.";
}
- (void)showFact:(UIButton *)sender {
    NSArray *selected = self.facts[self.categories.selectedSegmentIndex];
    self.index = (self.index + 1) % selected.count;
    self.fact.text = selected[self.index];
}
@end
