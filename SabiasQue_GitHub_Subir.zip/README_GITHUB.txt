PROYECTO ¿SABÍAS QUÉ?

Este proyecto contiene código Objective-C y un workflow de GitHub Actions.
IMPORTANTE: GitHub NO descomprime automáticamente un ZIP al subirlo.
Después de descargar este ZIP, hay que descomprimirlo en la computadora y
subir a GitHub el CONTENIDO de la carpeta.

Contenido:
- SabiasQue.xcodeproj/project.pbxproj
- SabiasQue/AppDelegate.h
- SabiasQue/AppDelegate.m
- SabiasQue/ViewController.h
- SabiasQue/ViewController.m
- SabiasQue/Info.plist
- .github/workflows/build.yml
